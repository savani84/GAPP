package gappp.model.dao;

import java.util.List;

import gappp.model.User;

public interface UserDao {

    User getUser( Integer id );

    List<User> getUsers();
    
    User saveUser(User user);
    
    boolean getUser( String email );
    
    User getUserByEmail( String email );
    
    User getUser( String email ,String password);
}