package gappp.model.dao;

import gappp.model.Role;

public interface RoleDao {
	Role getRole(String rolename);
}
