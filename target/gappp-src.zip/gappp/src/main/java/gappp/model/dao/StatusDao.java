package gappp.model.dao;

import gappp.model.Status;

import java.util.List;

public interface StatusDao {
   
	Status getStatusByName(String status);
}